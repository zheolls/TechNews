create view article_keyword_view as
  select `technews`.`article_keyword`.`keyword` AS `keyword`
  from `technews`.`article_keyword`
  group by `technews`.`article_keyword`.`articleid`;

