create view user_keyword_update_instant_view as
  select `a2`.`userid`                           AS `userid`,
         `a2`.`keyword`                          AS `keyword`,
         (to_days(now()) - to_days(`a2`.`date`)) AS `date`,
         count(0)                                AS `times`
  from (`technews`.`user_click` join (select `history`.`userid`                     AS `userid`,
                                             `technews`.`article_keyword`.`keyword` AS `keyword`,
                                             `history`.`date`                       AS `date`
                                      from (`technews`.`article_keyword` join (select `technews`.`article_history`.`userid`    AS `userid`,
                                                                                      `technews`.`article_history`.`articleid` AS `articleid`,
                                                                                      `technews`.`article_history`.`valid`     AS `valid`,
                                                                                      `technews`.`article_history`.`date`      AS `date`
                                                                               from `technews`.`article_history`
                                                                               where ((to_days(`technews`.`article_history`.`date`) - to_days(now())) < 60)
                                                                               order by `technews`.`article_history`.`date` desc) `history`)
                                      where (`history`.`articleid` = `technews`.`article_keyword`.`articleid`)
                                      order by `history`.`userid`) `a2`)
  where ((`a2`.`userid` = `technews`.`user_click`.`userid`) and (`technews`.`user_click`.`times` > 10))
  group by `a2`.`userid`, `a2`.`keyword`, `a2`.`date`
  order by `a2`.`userid`;

